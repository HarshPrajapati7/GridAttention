# GRIDTWIN-24 Training Report

Forecast date: 2024-06-17
Forecast origin: 2024-06-16 23:00:00
Selected model: ensemble
Dataset SHA-256: 8af13c5a525398d8834cdbd0b034cc56724eb23b55df5ad9df674c327e24b297

## Rolling validation leaderboard
| model                  |   clean_n |   clean_MAE |   clean_RMSE |   clean_WAPE_pct |   clean_sMAPE_pct |   clean_Bias_MW |   raw_WAPE_pct |   mean_fold_WAPE_pct |   folds_scored |
|:-----------------------|----------:|------------:|-------------:|-----------------:|------------------:|----------------:|---------------:|---------------------:|---------------:|
| cat_demand             |      1666 |     448.835 |      729.632 |          4.80599 |           4.7536  |      -1.15394   |        5.2115  |              4.64446 |              5 |
| lgbm_demand            |      1666 |     458.786 |      736.688 |          4.91254 |           4.88344 |      -0.0244217 |        5.31721 |              4.76653 |              5 |
| cat_context            |      1666 |     474.183 |      767.778 |          5.0774  |           5.05596 |     -14.8179    |        5.48102 |              4.94881 |              5 |
| patchtst               |      1666 |     486.413 |      799.645 |          5.20836 |           5.19073 |      62.9011    |        5.61578 |              5.07144 |              5 |
| lgbm_context           |      1666 |     486.644 |      751.392 |          5.21083 |           5.22012 |      10.1794    |        5.61399 |              5.10072 |              5 |
| dlinear                |      1666 |     497.566 |      778.717 |          5.32778 |           5.38551 |       9.49183   |        5.73781 |              5.25082 |              5 |
| seasonal_day           |      1666 |     625.855 |      956.616 |          6.70147 |           7.00598 |       0.552821  |        7.10176 |              6.65966 |              5 |
| seasonal_day_week_mean |      1666 |     787.673 |     1213.27  |          8.43415 |           8.13249 |      39.259     |        8.82482 |              7.92268 |              5 |
| seasonal_week          |      1666 |    1204.9   |     1927.64  |         12.9017  |          11.9052  |      77.9652    |       13.2697  |             11.6858  |              5 |
| chronos2               |      1666 |   43032.2   |    96379.5   |        460.775   |          39.0009  |   42798.2       |      459.015   |            347.569   |              5 |

## Untouched holdout
| model         |   quality_n |   quality_MAE |   quality_RMSE |   quality_WAPE_pct |   quality_sMAPE_pct |   quality_Bias_MW |   raw_WAPE_pct |
|:--------------|------------:|--------------:|---------------:|-------------------:|--------------------:|------------------:|---------------:|
| selected      |         671 |       922.044 |        1675.04 |            7.04225 |             8.41258 |          273.342  |        7.04225 |
| seasonal_day  |         671 |      1474.21  |        2561.58 |           11.2595  |            14.2126  |           49.2832 |       11.2595  |
| seasonal_week |         671 |      1788.55  |        2958.58 |           13.6603  |            16.7427  |          104.8    |       13.6603  |

P10-P90 empirical holdout coverage: 0.5589
Mean interval width (MW): 1315.04

## Data-quality notes
Missing hourly slots: 1045
Gross anomaly candidates: 5
Masked for modelling: 5

Accuracy claims must be based on the untouched holdout and reported with data-quality caveats.