# GRIDTWIN-24 Training Report

- Dataset SHA-256: `8af13c5a525398d8834cdbd0b034cc56724eb23b55df5ad9df674c327e24b297`
- Forecast date: `2024-06-17`
- Issue origin: `2024-06-16 23:00:00`
- Selected model: `chronos2`
- Device: `cuda`
- Missing hourly slots through issue origin: `1045`
- Rows excluded after issue origin: `0`
- Quality-screened isolated gross-error labels: `5`

## Untouched holdout — raw observations (primary evaluation)

- Selected model WAPE: `7.8505%`
- Selected model MAE: `1027.87 MW`
- Selected model RMSE: `1954.32 MW`
- Selected model bias: `386.66 MW`
- Seasonal-blend baseline WAPE: `10.7421%`

## Uncertainty

- Calibrated against raw out-of-time residuals. Empirical P10–P90 holdout coverage: `0.4814` (nominal target 0.80)
- Mean interval width: `1062.47 MW`

## Interpretation

The holdout is the final generalisation check and was not used for tuning or selection. If the selected model does not beat the seasonal baseline on raw holdout WAPE, do not claim an improvement. Review the horizon errors, data anomaly audit and fold stability. The prediction interval is empirical; it is not a guarantee under distribution shift.
